<template>
  <div class="mt-5 list-group rounded">
    <drop
      class="box"
      @drop="handelDrop"
      style="height:100%;min-height: 440px;"
    >
      {{generateField}}
      <vs-collapse
        v-for="(eachField,index) in generateField"
        :key="index"
      >

        <vs-collapse-item :open="true">
          <pre> {{eachField}}</pre>
          <div slot="header">

          </div>
          <div>

          </div>

          <vs-button @click.prevent="generateField.splice(index,1)">Delete</vs-button>
        </vs-collapse-item>
      </vs-collapse>
    </drop>
    <div class="preview">

      {{model}}

      {{schema}}

      <vue-form-generator
        :schema="schema"
        :model="model"
        v-if="model"
      ></vue-form-generator>
    </div>
  </div>
</template>

<script>
import { Drop } from "vue-drag-drop"
import VueFormGenerator from "vue-form-generator";

export default {
  components: {
    Drop,
    "vue-form-generator": VueFormGenerator.component,
  },
  data () {
    return {
      generateField: [],
      active: false,
      schema: {
        fields: []
      },
      model: {}
    }
  },
  watch: {
    generateField: {
      deep: true,
      handler () {
        console.log(this.generateField)
        this.$set(this.schema, "fields", this.generateField)
      }
    }
  },
  methods: {
    handelDrop (data, event) {
      this.generateField.push(data)
    },
  },
  computed: {
    getField () {
      return this.generateField
    },
  }
}
</script>

<style>
.mainbox {
  height: 95%;
  width: 100%;
}
.box {
  width: 100%;
  height: 100%;
  background-color: whitesmoke;
  overflow: auto;
  padding: 5px;
}

.dropmainbox {
  border: 2px dashed rgb(139, 132, 132);
  background-color: #edfbff;
  border-radius: 8px;
  height: 95%;
}

.a {
  border-right-style: dashed;
  border-color: rgb(139, 132, 132);
  border-width: 2px;
}

.b {
  position: absolute;
  bottom: 0px;
  width: 100px;
}

td {
  padding: 15px;
}

table,
td {
  border: 1px solid black;
  border-collapse: collapse;
}

.save {
  border: 1.5px solid #005e85;
  color: #005e85;
  background-color: #f9feff;
}

.save:hover {
  border: 2px solid #005e85;
}

.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
  display: table;
  transition: opacity 0.3s ease;
}

.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}

.modal-body-lg {
  position: relative;
  height: 400px;
  overflow-y: auto;
  overflow-y: scroll;
  padding: 10px;
}

.modal-body-panel {
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 10px;
}

select,
#search-group {
  border: 1px solid #2567bb;
  color: #2567bb;
}

.continue {
  background-color: #005e85;
  color: #f9feff;
}

.cancel {
  border: 1.5px solid #005e85;
  color: #005e85;
}

.cancel:hover {
  border: 2px solid #005e85;
}

.createAQ {
  background-color: #005e85;
  color: #f9feff;
}

.modal-dialog-lg {
  max-width: 900px;
}
</style>