<template>
  <div class="row justify-content-start">
    <div class="col-1">
              <img class="ms-0"
        src="../../assets/Abalogo.png"
        alt="ABA"
        style="width: 60px; height: 40px"
      />

    </div>
    <div class="col-2 bg-primary">
      <h5>Admin Utility</h5>
    </div>
  </div>
</template>
<script>
export default {
  name: "head-item",
};
</script>

<style>
</style>