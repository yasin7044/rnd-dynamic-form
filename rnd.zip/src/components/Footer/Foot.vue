<template>
  <h6 class="text-light">Copyright 2022 &copy; ABA Admin Utility</h6>
</template>

<script>
export default {
name:"foot-item"
}
</script>

<style>

</style>